function handleSubmit() {
  var email = document.getElementById("email").value;
  if (email.trim() === "") {
    alert("Please enter your email address.");
  } else {
    alert("Thank you, \u{1F91D}");
  }
}

function toggle() {
  var trailer = document.querySelector(".trailer");
  var video = document.querySelector("video");
  trailer.classList.toggle("active");
  video.pause();
  video.currentTime = 0;
}
